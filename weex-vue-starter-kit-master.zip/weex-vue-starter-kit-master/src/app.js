import App from './index.vue'

new Vue({
  el: '#root',
  render: h => h(App)
})
