import weexVueRenderer from 'weex-vue-render'

Vue.use(weexVueRenderer)
